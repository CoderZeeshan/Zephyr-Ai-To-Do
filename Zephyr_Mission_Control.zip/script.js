let tasks=JSON.parse(localStorage.getItem('tasks')||'[]');
let xp=Number(localStorage.getItem('xp')||0);

function save(){
localStorage.setItem('tasks',JSON.stringify(tasks));
localStorage.setItem('xp',xp);
}

function coach(){
const pending=tasks.filter(t=>!t.done).length;
const msg=document.getElementById('coach');
if(tasks.length===0) msg.innerText='Add tasks to begin your mission.';
else if(pending===0) msg.innerText='Excellent. All missions completed today.';
else if(pending<=2) msg.innerText='You are close to victory. Finish the remaining tasks.';
else msg.innerText='Focus on one task at a time. Momentum beats motivation.';
}

function render(){
const ul=document.getElementById('tasks');
ul.innerHTML='';
let done=0;

tasks.forEach((t,i)=>{
if(t.done) done++;
const li=document.createElement('li');
li.innerHTML=`<input type="checkbox" ${t.done?'checked':''}
onclick="toggle(${i})"> ${t.name} (+${t.xp} XP)`;
ul.appendChild(li);
});

const percent=tasks.length?Math.round(done/tasks.length*100):0;
document.getElementById('progressBar').value=percent;
document.getElementById('progressText').innerText=percent+'%';

document.getElementById('xp').innerText=xp;
document.getElementById('level').innerText=Math.floor(xp/100)+1;
document.getElementById('xpBar').value=xp%100;

coach();
save();
}

function addTask(){
const name=document.getElementById('taskInput').value;
const taskxp=Number(document.getElementById('taskXP').value);
if(!name) return;
tasks.push({name:name,xp:taskxp,done:false});
document.getElementById('taskInput').value='';
render();
}

function toggle(i){
if(!tasks[i].done) xp+=tasks[i].xp;
else xp-=tasks[i].xp;
tasks[i].done=!tasks[i].done;
render();
}

render();
